ShinsDiffPatcher
================

ShinsDiffPatcher compat�vel com Ragexe
